// src/core/config/shape/schema.ts
var SchemaNode = class {
  kind;
  fallback;
  hasDefault = false;
  desc = "";
  label = "";
  multiline = false;
  isHidden = false;
  isDeprecated = false;
  isExperimental = false;
  isRequired = false;
  isSecret = false;
  lower;
  upper;
  intOnly = false;
  members = [];
  item;
  shape;
  constructor(kind) {
    this.kind = kind;
  }
  default(value) {
    this.fallback = value;
    this.hasDefault = true;
    return this;
  }
  title(label) {
    this.label = label;
    return this;
  }
  description(text2) {
    this.desc = text2;
    return this;
  }
  hidden(value = true) {
    this.isHidden = value;
    return this;
  }
  deprecated(value = true) {
    this.isDeprecated = value;
    return this;
  }
  experimental(value = true) {
    this.isExperimental = value;
    return this;
  }
  required(value = true) {
    this.isRequired = value;
    return this;
  }
  role(name) {
    if (name === "secret") this.isSecret = true;
    if (name === "textarea" && this.kind === "string") this.multiline = true;
    return this;
  }
  min(value) {
    this.lower = value;
    return this;
  }
  max(value) {
    this.upper = value;
    return this;
  }
  integer() {
    this.intOnly = true;
    return this;
  }
  /** union：成员是字面量，或 { value, label } */
  of(...values) {
    this.members = values;
    return this;
  }
  /** array：元素 schema */
  items(node) {
    this.item = node;
    return this;
  }
  /** object：字段表 */
  fields(shape) {
    this.shape = shape;
    return this;
  }
  get defaultValue() {
    if (this.hasDefault) return this.fallback;
    if (this.kind === "boolean") return false;
    if (this.kind === "number") return this.lower ?? 0;
    if (this.kind === "string") return "";
    if (this.kind === "union") return this.memberValues()[0];
    if (this.kind === "array") return [];
    if (this.kind === "object") return this.defaults();
    return void 0;
  }
  memberValues() {
    return this.members.map((m) => isPlainObject(m) && "value" in m ? m.value : m);
  }
  /** object 形态的全部默认值 */
  defaults() {
    if (this.kind !== "object" || !this.shape) return {};
    const out = {};
    for (const [key, node] of Object.entries(this.shape)) out[key] = node.defaultValue;
    return out;
  }
  validate(input) {
    const missing = input === void 0 || input === null;
    if (missing) {
      if (this.isRequired && !this.hasDefault) return { ok: false, error: "\u5FC5\u586B\u9879\u4E3A\u7A7A" };
      return { ok: true, value: this.defaultValue };
    }
    switch (this.kind) {
      case "boolean":
        if (typeof input === "boolean") return { ok: true, value: input };
        if (input === "true" || input === 1) return { ok: true, value: true };
        if (input === "false" || input === 0) return { ok: true, value: false };
        return { ok: false, error: "\u8981 true / false" };
      case "string":
        if (this.isRequired && typeof input === "string" && !input.trim()) return { ok: false, error: "\u5FC5\u586B\u9879\u4E3A\u7A7A" };
        if (typeof input === "string") return { ok: true, value: input };
        if (typeof input === "number") return { ok: true, value: String(input) };
        return { ok: false, error: "\u8981\u6587\u672C" };
      case "number": {
        const n = typeof input === "number" ? input : Number(input);
        if (!Number.isFinite(n)) return { ok: false, error: "\u8981\u6570\u5B57" };
        if (this.intOnly && !Number.isInteger(n)) return { ok: false, error: "\u8981\u6574\u6570" };
        if (this.lower !== void 0 && n < this.lower) return { ok: false, error: `\u4E0D\u80FD\u5C0F\u4E8E ${this.lower}` };
        if (this.upper !== void 0 && n > this.upper) return { ok: false, error: `\u4E0D\u80FD\u5927\u4E8E ${this.upper}` };
        return { ok: true, value: n };
      }
      case "union": {
        const values = this.memberValues();
        if (values.includes(input)) return { ok: true, value: input };
        return { ok: false, error: `\u53EA\u80FD\u662F ${values.join(" / ")}` };
      }
      case "array": {
        if (!Array.isArray(input)) return { ok: false, error: "\u8981\u6570\u7EC4" };
        if (!this.item) return { ok: true, value: input };
        const out = [];
        for (const [i, v] of input.entries()) {
          const r = this.item.validate(v);
          if (!r.ok) return { ok: false, error: `\u7B2C ${i + 1} \u9879\uFF1A${r.error}` };
          out.push(r.value);
        }
        return { ok: true, value: out };
      }
      case "object": {
        if (!isPlainObject(input)) return { ok: false, error: "\u8981\u5BF9\u8C61" };
        if (!this.shape) return { ok: true, value: input };
        const out = {};
        for (const [key, node] of Object.entries(this.shape)) {
          const r = node.validate(input[key]);
          if (!r.ok) return { ok: false, error: `${key}\uFF1A${r.error}` };
          out[key] = r.value;
        }
        return { ok: true, value: out };
      }
      default:
        return { ok: true, value: input };
    }
  }
  /** 面板表单：object 展开成字段数组 */
  toSettings(prefix = "") {
    if (this.kind !== "object" || !this.shape) return [];
    const fields = [];
    for (const [key, node] of Object.entries(this.shape)) {
      fields.push(node.toField(prefix ? `${prefix}.${key}` : key));
    }
    return fields;
  }
  toField(key) {
    const field = {
      key,
      label: this.label || this.desc || key,
      type: this.fieldType()
    };
    if (this.hasDefault && !this.containsSecret()) field.default = this.fallback;
    if (this.kind === "object") field.fields = this.toSettings();
    if (this.item) field.item = this.item.toField("");
    if (this.intOnly) field.step = 1;
    if (this.desc) field.hint = this.desc;
    if (this.upper !== void 0) field.max = this.upper;
    if (this.lower !== void 0) field.min = this.lower;
    if (this.kind === "union") {
      field.options = this.members.map((m) => {
        if (isPlainObject(m) && "value" in m) {
          const item = m;
          return { value: String(item.value), label: item.label ?? String(item.value) };
        }
        return { value: String(m), label: String(m) };
      });
    }
    if (this.isRequired) field.required = true;
    if (this.isHidden) field.hidden = true;
    if (this.isDeprecated) field.deprecated = true;
    if (this.isExperimental) field.experimental = true;
    return field;
  }
  containsSecret() {
    return this.isSecret || Boolean(this.item?.containsSecret()) || Object.values(this.shape || {}).some((node) => node.containsSecret());
  }
  fieldType() {
    if (this.containsSecret()) return "password";
    if (this.kind === "object" || this.kind === "array") return this.kind;
    if (this.kind === "boolean") return "boolean";
    if (this.kind === "number") return "number";
    if (this.kind === "union") return "select";
    if (this.multiline) return "textarea";
    return "text";
  }
};
function isPlainObject(v) {
  return !!v && typeof v === "object" && !Array.isArray(v);
}
var Schema = {
  boolean: () => new SchemaNode("boolean"),
  string: () => new SchemaNode("string"),
  number: () => new SchemaNode("number"),
  natural: () => new SchemaNode("number").min(0).integer(),
  percent: () => new SchemaNode("number").min(0).max(1),
  union: (values) => new SchemaNode("union").of(...values),
  array: (item) => new SchemaNode("array").items(item),
  object: (shape) => new SchemaNode("object").fields(shape)
};

// src/core/message/element/parse.ts
var supported = /* @__PURE__ */ new Set([
  "text",
  "at",
  "image",
  "img",
  "voice",
  "audio",
  "video",
  "file",
  "face",
  "poke",
  "quote",
  "reply",
  "forward",
  "message",
  "author",
  "br",
  "translatevoice",
  "sharp",
  "emoji",
  "a",
  "b",
  "strong",
  "i",
  "em",
  "u",
  "ins",
  "s",
  "del",
  "spl",
  "code",
  "sup",
  "sub",
  "p",
  "button"
]);
var entities = { amp: "&", quot: '"', apos: "'", lt: "<", gt: ">" };
function decode(value) {
  return value.replace(/&(amp|quot|apos|lt|gt|#\d+|#x[\da-f]+);/gi, (original, name) => {
    if (!name.startsWith("#")) return entities[name] ?? original;
    const code = name[1].toLowerCase() === "x" ? parseInt(name.slice(2), 16) : Number(name.slice(1));
    return code > 0 && code <= 1114111 && !(code >= 55296 && code <= 57343) ? String.fromCodePoint(code) : original;
  });
}
function finish({ type, attrs, children }) {
  if (["img", "audio", "video", "file"].includes(type) && attrs.src !== void 0) {
    attrs.url = attrs.src;
    delete attrs.src;
  }
  if (type === "translatevoice") type = "translateVoice";
  if (type === "img") type = "image";
  if (type === "audio") type = "voice";
  if (type === "text") return { type, attrs: { content: String(attrs.content ?? children.map((child) => child.attrs.content ?? "").join("")) } };
  if (type === "file" && !attrs.url && !attrs.src && children.every((child) => child.type === "text")) {
    const url = children.map((child) => child.attrs.content).join("").trim();
    if (url) return { type, attrs: { ...attrs, url } };
  }
  return children.length ? { type, attrs, children } : { type, attrs };
}
function parse(source) {
  const input = String(source ?? "");
  const root = [];
  const stack = [];
  const opening = /<!--|<(\/?)([a-z][\w:-]*)/gi;
  const end = /(?:[^'"<>]|"[^"]*"|'[^']*')*>/y;
  const attribute = /\s+([\w:-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>]+)))?/gy;
  let ignored;
  let cursor = 0;
  const append = (element) => {
    const children = stack.at(-1)?.children ?? root;
    if (element.type === "text") {
      if (!element.attrs.content) return;
      const previous = children.at(-1);
      if (previous?.type === "text") {
        previous.attrs.content += element.attrs.content;
        return;
      }
    }
    children.push(element);
  };
  for (const match of input.matchAll(opening)) {
    if (match.index < cursor) continue;
    if (!ignored) append({ type: "text", attrs: { content: decode(input.slice(cursor, match.index)) } });
    if (match[0] === "<!--") {
      const close = input.indexOf("-->", match.index + 4);
      if (close < 0) return root;
      cursor = close + 3;
      continue;
    }
    end.lastIndex = match.index + match[0].length;
    const tail = end.exec(input);
    if (!tail) return root;
    cursor = end.lastIndex;
    const type = match[2].toLowerCase();
    const closing = Boolean(match[1]);
    const body = tail[0].slice(0, -1).trimEnd();
    const empty = body.endsWith("/");
    if (ignored) {
      if (ignored.type === type && closing && !body && --ignored.depth === 0) ignored = void 0;
      else if (ignored.type === type && !closing && !empty) ignored.depth++;
      continue;
    }
    if (closing) {
      if (body) continue;
      const index = stack.findLastIndex((frame2) => frame2.type === type);
      if (index >= 0) {
        const frame2 = stack[index];
        stack.length = index;
        append(finish(frame2));
      }
      continue;
    }
    const sourceAttrs = (empty ? body.slice(0, -1) : body).trimEnd();
    const attrs = /* @__PURE__ */ Object.create(null);
    let offset = 0;
    attribute.lastIndex = 0;
    for (let field; field = attribute.exec(sourceAttrs); ) {
      attrs[field[1]] = field[2] === void 0 && field[3] === void 0 && field[4] === void 0 ? true : decode(field[2] ?? field[3] ?? field[4]);
      offset = attribute.lastIndex;
    }
    if (!supported.has(type) || offset !== sourceAttrs.length) {
      if (!empty) ignored = { type, depth: 1 };
      continue;
    }
    const frame = { type, attrs: { ...attrs }, children: [] };
    if (empty || type === "br") append(finish(frame));
    else stack.push(frame);
  }
  if (!ignored) append({ type: "text", attrs: { content: decode(input.slice(cursor)) } });
  return root;
}

// src/core/message/element/element.ts
function create(type, attrs = {}, children) {
  const element = { type, attrs: { ...attrs } };
  if (children && children.length) element.children = children;
  return element;
}
function text(content) {
  return create("text", { content: String(content ?? "") });
}
var h = Object.assign(
  (type, attrs, children) => create(type, attrs, children),
  {
    text,
    at: (id, name) => create("at", name ? { id: String(id), name } : { id: String(id) }),
    image: (url, extra = {}) => create("image", { url, ...extra }),
    voice: (url, extra = {}) => create("voice", { url, ...extra }),
    video: (url, extra = {}) => create("video", { url, ...extra }),
    file: (url, name) => create("file", name ? { url, name } : { url }),
    face: (id) => create("face", { id: String(id) }),
    poke: (id) => create("poke", id == null ? {} : { id: String(id) }),
    quote: (id) => create("quote", { id: String(id) }),
    forward: (idOrChildren) => Array.isArray(idOrChildren) ? create("forward", {}, idOrChildren) : create("forward", { id: String(idOrChildren) }),
    parse,
    stringify,
    select,
    normalize,
    degrade,
    isElement
  }
);
function isElement(value) {
  return !!value && typeof value === "object" && typeof value.type === "string" && !!value.attrs && typeof value.attrs === "object";
}
function escapeAttr(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
}
function escapeText(value) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function stringify(elements) {
  return normalize(elements).map(render).join("");
}
function render(element) {
  if (element.type === "text") return escapeText(String(element.attrs.content ?? ""));
  const attrs = Object.entries(element.attrs).filter(([, v]) => v !== void 0 && v !== null).map(([k, v]) => ` ${k}="${escapeAttr(v)}"`).join("");
  if (!element.children || !element.children.length) return `<${element.type}${attrs}/>`;
  return `<${element.type}${attrs}>${element.children.map(render).join("")}</${element.type}>`;
}
function normalize(source) {
  const list = [];
  const push = (element) => {
    const last = list[list.length - 1];
    if (element.type === "text") {
      const content = String(element.attrs.content ?? "");
      if (!content) return;
      if (last && last.type === "text") {
        last.attrs.content = String(last.attrs.content ?? "") + content;
        return;
      }
      list.push(create("text", { content }));
      return;
    }
    list.push(element.children ? create(element.type, element.attrs, normalize(element.children)) : element);
  };
  if (source === null || source === void 0) return list;
  if (typeof source === "string") return parse(source);
  if (Array.isArray(source)) {
    for (const item of source) if (item) push(item);
    return list;
  }
  push(source);
  return list;
}
function select(source, selector) {
  const test = typeof selector === "string" ? (element) => element.type === selector : selector;
  const out = [];
  const walk = (list) => {
    for (const element of list) {
      if (test(element)) out.push(element);
      if (element.children) walk(element.children);
    }
  };
  walk(normalize(source));
  return out;
}
var MEDIA_CAPABILITY = {
  image: "image",
  voice: "voice",
  video: "video",
  file: "file",
  forward: "forward",
  quote: "quote",
  poke: "poke"
};
var PLACEHOLDER = {
  image: () => "[\u56FE\u7247]",
  voice: () => "[\u8BED\u97F3]",
  poke: () => "[\u6233\u4E00\u6233]",
  video: () => "[\u89C6\u9891]",
  file: (element) => "[\u6587\u4EF6] " + String(element.attrs.name || element.attrs.url || ""),
  forward: () => "[\u5408\u5E76\u8F6C\u53D1]"
};
function degrade(source, supports) {
  const out = [];
  for (const element of normalize(source)) {
    const needed = MEDIA_CAPABILITY[element.type];
    if (needed && !supports(needed)) {
      if (element.type === "quote") continue;
      const placeholder = PLACEHOLDER[element.type];
      out.push(text(placeholder ? placeholder(element) : "[" + element.type + "]"));
      continue;
    }
    if (element.type === "at" && !supports("at")) {
      out.push(text("@" + String(element.attrs.name || element.attrs.id || "")));
      continue;
    }
    if (element.type === "face" && !supports("face")) {
      out.push(text("[\u8868\u60C5]"));
      continue;
    }
    out.push(element.children ? create(element.type, element.attrs, degrade(element.children, supports)) : element);
  }
  return normalize(out);
}

// src/core/bot/index.ts
var UnsupportedApiError = class extends Error {
  code = "UNSUPPORTED_API";
  constructor(bot, api) {
    super(`${bot.platform}/${bot.id} \u4E0D\u652F\u6301 ${api}`);
    this.name = "UnsupportedApiError";
  }
};
var Bot = class {
  async internal(action, params, options) {
    void params;
    void options;
    throw new UnsupportedApiError(this, `internal(${action})`);
  }
  getSelfId() {
    return this.selfId;
  }
  async getSelf() {
    return { id: this.selfId };
  }
  async getUser(userId) {
    void userId;
    throw new UnsupportedApiError(this, "getUser");
  }
  async getFriendList() {
    throw new UnsupportedApiError(this, "getFriendList");
  }
  async getGuild(guildId) {
    void guildId;
    throw new UnsupportedApiError(this, "getGuild");
  }
  async getGuildList() {
    throw new UnsupportedApiError(this, "getGuildList");
  }
  async getUserList(guildId) {
    void guildId;
    throw new UnsupportedApiError(this, "getUserList");
  }
  async getChannel(channelId, type) {
    void channelId;
    throw new UnsupportedApiError(this, "getChannel");
  }
  async getChannelList(guildId) {
    void guildId;
    throw new UnsupportedApiError(this, "getChannelList");
  }
  async getMessage(channelId, messageId) {
    void channelId;
    void messageId;
    throw new UnsupportedApiError(this, "getMessage");
  }
  async getMessageList(channelId, query) {
    void channelId;
    void query;
    throw new UnsupportedApiError(this, "getMessageList");
  }
  async deleteMessage(channelId, messageId) {
    void channelId;
    void messageId;
    throw new UnsupportedApiError(this, "deleteMessage");
  }
  async updateMessage(channelId, messageId, content) {
    void channelId;
    void messageId;
    void content;
    throw new UnsupportedApiError(this, "updateMessage");
  }
  async createReaction(channelId, messageId, emoji) {
    void channelId;
    void messageId;
    void emoji;
    throw new UnsupportedApiError(this, "createReaction");
  }
  async deleteReaction(channelId, messageId, emoji) {
    void channelId;
    void messageId;
    void emoji;
    throw new UnsupportedApiError(this, "deleteReaction");
  }
};
export {
  Bot,
  Schema,
  UnsupportedApiError,
  h
};
